// 生命周期函数
Page({
  //页面的初始数据
  data: {

  },
  // 页面加载完触发
  onLoad: function (options) {
    //发送异步请求初始化页面数据
  },
  // 当前页面刚开始显示的时候触发
  onShow: function () {

  },
  // 当前页面渲染完成时触发
  onReady: function () {

  },
  // 当前页面隐藏时触发
  onHide: function () {

  },
  // 当前页面被卸载时触发（跳转到别的页面没有返回按钮）
  onUnload: function () {

  },
  // 页面下拉触发
  onPullDownRefresh: function () {

  },
  // 页面上拉到最底部时触发
  onReachBottom: function () {
    //实现上拉加载下一页到操作
  },
  //用户点击右上角分享时触发
  onShareAppMessage: function () {

  },
  // 页面滚动时触发
  onPageScroll(){

  },
  // 页面尺寸发生改变时触发
  onResize(){

  },
  // 如果当前页是tab页时，点击当前tab触发
  onTabItemTap(){

  }
})