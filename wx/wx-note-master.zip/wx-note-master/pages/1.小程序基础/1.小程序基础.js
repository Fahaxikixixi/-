Page({
  data:{
    obj:{
      name:"code7s",
      age: 23,
      info: "title"
    },
    list:[1,2,3,4]
  }
})