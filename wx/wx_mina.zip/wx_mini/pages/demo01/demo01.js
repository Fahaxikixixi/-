// pages/demo01/demo01.js
Page({

  
  data: {
    person:[{id:0,mes:"zgg"},{id:1,mes:"zgg01"},{id:2,mes:"zgg02"}],
    arr:["zgg01","P_loo","we1ist","xxLu","fourever"]
  }

})