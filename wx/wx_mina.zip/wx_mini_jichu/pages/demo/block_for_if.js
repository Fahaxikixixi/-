// pages/demo/block_for_if.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        demolist: {
            name: 'P_looo',
            age: 18,
            text: 'is God'
        }
    },

})